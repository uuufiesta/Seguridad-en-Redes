# Level X

## Objetivo

## Datos de Acceso

## Solución
``` bash
C:\WINDOWS\system32>ssh bandit?@bandit.labs.overthewire.org -p 2220
                         _                     _ _ _
                        | |__   __ _ _ __   __| (_) |_
                        | '_ \ / _` | '_ \ / _` | | __|
                        | |_) | (_| | | | | (_| | | |_
                        |_.__/ \__,_|_| |_|\__,_|_|\__|


                      This is an OverTheWire game server.
            More information on http://www.overthewire.org/wargames

bandit?@bandit.labs.overthewire.org's password:
```
## Notas Adicionales

## Referencias

