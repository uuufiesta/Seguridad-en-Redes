# Level 2-3

## Objetivo
Find the flag in a file called "spaces in this file name"

## Datos de Acceso
ssh bandit2@bandit.labs.overthewire.org -p 2220
rRGizSaX8Mk1RTb1CNQoXTcYZWU6lgzi
## Solución
``` bash
C:\WINDOWS\system32>ssh bandit2@bandit.labs.overthewire.org -p 2220
                         _                     _ _ _
                        | |__   __ _ _ __   __| (_) |_
                        | '_ \ / _` | '_ \ / _` | | __|
                        | |_) | (_| | | | | (_| | | |_
                        |_.__/ \__,_|_| |_|\__,_|_|\__|


                      This is an OverTheWire game server.
            More information on http://www.overthewire.org/wargames

bandit2@bandit.labs.overthewire.org's password:
bandit2@bandit:~$ nano spaces\ in\ this\ f
aBZ0W5EmUfAf7kHTQeOwd8bauFJ2lAiG
```
## Notas Adicionales
- nano: Abre archivos de texto
## Referencias

