# Level 26-27

## Objetivo
Good job getting a shell! Now hurry and grab the password for bandit27!
## Datos de Acceso
ssh bandit26@bandit.labs.overthewire.org -p 2220
c7GvcKlw9mC7aUQaPx7nwFstuAIBw1o1
## Solución
``` bash
C:\WINDOWS\system32>ssh bandit26@bandit.labs.overthewire.org -p 2220
                         _                     _ _ _
                        | |__   __ _ _ __   __| (_) |_
                        | '_ \ / _` | '_ \ / _` | | __|
                        | |_) | (_| | | | | (_| | | |_
                        |_.__/ \__,_|_| |_|\__,_|_|\__|


                      This is an OverTheWire game server.
            More information on http://www.overthewire.org/wargames

bandit26@bandit.labs.overthewire.org's password:
bandit26@bandit:~$ ./bandit27-do cat /etc/bandit_pass/bandit27
YnQpBuifNMas1hcUFk70ZmqkhUU2EuaS
```
## Notas Adicionales

## Referencias

