# Cookies

## Descripcion

Who doesn't love cookies? Try to figure out the best one. [http://mercury.picoctf.net:54219/](http://mercury.picoctf.net:54219/)

## Pistas

## Solucion

```
Abrimos el link http://mercury.picoctf.net:54219/ e ingresamos snickerdoodle que es lo que se ve de fondo vamos al editor de cookies y vemos que tenemos una que es llamada name con valor de 0 le damos el valor de 1 mostrandonos algo distinto usamos un valor negativo y nos damos cuenta que no es valido seguimos probando numeros hacia arriba probando si alguno contiene la flag hasta el valor de 18 donde nos da la flag:
picoCTF{3v3ry1_l0v3s_c00k135_96cdadfd}
```

## Bandera

picoCTF{3v3ry1_l0v3s_c00k135_96cdadfd}

## Notas adicionales

## Referencias