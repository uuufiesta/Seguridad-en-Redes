# tunn3l v1s10n

## Descripcion

We found this [file](https://mercury.picoctf.net/static/01be2b38ba97802285a451b94505ea75/tunn3l_v1s10n). Recover the flag.

## Pistas

-   Weird that it won't display right...

## Solucion

```
Descargamos el archivo de la pagina despues usando un editor de hexadecimal corregimos a un formato correcto BMP y nos muestra notaflag{sorry} la cual no es la bandera por lo que ajustamos el tamaño de la imagen obteniendo la bandera picoCTF{qu1t3_a_v13w_2020}
```

## Bandera

picoCTF{qu1t3_a_v13w_2020}

## Notas adicionales

## Referencias