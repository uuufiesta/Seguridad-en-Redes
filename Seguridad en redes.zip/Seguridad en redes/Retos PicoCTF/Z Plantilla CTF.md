
# X-Titulo
## Descripcion

## Pistas

## Solucion
``` bash

```
## Bandera
picoCTF{}