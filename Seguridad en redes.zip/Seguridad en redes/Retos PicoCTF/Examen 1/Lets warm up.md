
# 0-Lets warm up
## Descripcion
If I told you a word started with 0x70 in hexadecimal, what would it start with in ASCII?

## Pistas

## Solucion
Convertiremos el numero dado en hexadecimal a decimal y encontraremos el simbolo equivalente al numero en decimal.

## Bandera
picoCTF{p}