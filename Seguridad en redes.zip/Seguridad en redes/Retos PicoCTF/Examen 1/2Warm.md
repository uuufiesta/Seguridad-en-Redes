
# 2-2Warm
## Descripcion
Can you convert the number 42 (base 10) to binary (base 2)?
## Pistas

## Solucion
Covertiremos el numero 42 de decimal a binario para obtener la bandera
## Bandera
picoCTF{101010}