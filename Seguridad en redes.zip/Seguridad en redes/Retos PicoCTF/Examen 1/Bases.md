
# Bases
## Descripcion
What does this `bDNhcm5fdGgzX3IwcDM1` mean? I think it has something to do with bases.
## Pistas

## Solucion
``` bash
Utiizamos la herramienta para convertir de base 64 de Cyberchef
```
## Bandera
picoCTF{l3arn_th3_r0p35}

## Referencias
https://gchq.github.io/CyberChef/#recipe=From_Base64('A-Za-z0-9%2B/%3D',true,false)&input=YkROaGNtNWZkR2d6WDNJd2NETTEg