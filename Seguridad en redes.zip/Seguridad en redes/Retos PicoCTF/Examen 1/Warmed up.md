
# 1-Warmed Up
## Descripcion
What is 0x3D (base 16) in decimal (base 10)?

## Pistas

## Solucion
Convertiremos el numero hexadecimal a decimal el resultado sera nuestra bandera

## Bandera
picoCTF{61}