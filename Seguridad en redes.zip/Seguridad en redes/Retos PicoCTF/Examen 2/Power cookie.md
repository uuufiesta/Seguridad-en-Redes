# Power Cookie

## Descripcion

Can you get the flag?Go to this [website](http://saturn.picoctf.net:65442/) and see what you can discover.

## Pistas

-   Do you know how to modify cookies?

## Solucion

```
Ingresamos a la pagina web y le damos click a continuar como invitado recibiendo el siguiente mensaje We apologize, but we have no guest services at the moment. iremos al cookie editor y cambiaremos el valor de la variable isAdmin a 1 obteniendo la bandera:
picoCTF{gr4d3_A_c00k13_5d2505be}

```

## Bandera

picoCTF{gr4d3_A_c00k13_5d2505be}

## Notas adicionales

## Referencias