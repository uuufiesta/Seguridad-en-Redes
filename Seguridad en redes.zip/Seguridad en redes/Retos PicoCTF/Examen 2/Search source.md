# Search Source

## Descripcion

The developer of this website mistakenly left an important artifact in the website source, can you find it?The website is [here](http://saturn.picoctf.net:50303/)

## Pistas

-   How could you mirror the website on your local machine so you could use more powerful tools for searching?

## Solucion

```
Ingresamos a la pagina web y le damos click derecho y le damos click en view page source luego ya viendo el codigo fuente abrimos varios archivos para ver si se encuentra la bandera y el archivo style.css tiene la bandera:
/** banner_main picoCTF{1nsp3ti0n_0f_w3bpag3s_587d12b8} **/
```

## Bandera

picoCTF{1nsp3ti0n_0f_w3bpag3s_587d12b8}

## Notas adicionales

## Referencias