# m00nwalk

## Descripcion

Decode this [message](https://jupiter.challenges.picoctf.org/static/fc1edf07742e98a480c6aff7d2546107/message.wav) from the moon.

## Pistas

-   How did pictures from the moon landing get sent back to Earth?
-   What is the CMU mascot?, that might help select a RX option

## Solucion

```
Descargamos el archivo de la pagina message.was y usamos la aplicacion de linux qsstv para convertirla a imagen dandonos la bandera que es picoCTF{beep_boop_im_in_space}
```

## Bandera

picoCTF{beep_boop_im_in_space}

## Notas adicionales

## Referencias