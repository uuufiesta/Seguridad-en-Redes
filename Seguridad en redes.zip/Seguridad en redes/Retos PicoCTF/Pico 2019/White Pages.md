# WhitePages

## Descripcion

I stopped using YellowPages and moved onto WhitePages... but [the page they gave me](https://jupiter.challenges.picoctf.org/static/95be9526e162185c741259a75dffa0ab/whitepages.txt) is all blank!

## Pistas

## Solucion

```
Descargamos el archivo de la pagina Whitepages.txt lo abrimos y notamos que tiene caracteres invisibles seleccionamos el primero y lo remplazamos por un 0 luego los espacios que quedan los remplazamos por 1 luego usamos un convertidor de binario a ASCII para obtener la bandera
picoCTF

		SEE PUBLIC RECORDS & BACKGROUND REPORT
		5000 Forbes Ave, Pittsburgh, PA 15213
		picoCTF{not_all_spaces_are_created_equal_7100860b0fa779a5bd8ce29f24f586dc}
```

## Bandera

picoCTF{not_all_spaces_are_created_equal_7100860b0fa779a5bd8ce29f24f586dc}

## Notas adicionales

## Referencias

-   [Calculadora binario a ascii](https://www.calculadoraconversor.com/binario-a-ascii/)