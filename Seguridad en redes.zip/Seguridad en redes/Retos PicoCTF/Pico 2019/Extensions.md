# extensions

## Descripcion

This is a really weird text file [TXT](https://jupiter.challenges.picoctf.org/static/e7e5d188621ee705ceeb0452525412ef/flag.txt)? Can you find the flag?

## Pistas

-   How do operating systems know what kind of file it is? (It's not just the ending!
-   Make sure to submit the flag as picoCTF{XXXXX}

## Solucion

```
Descargamos el archivo de la pagina flag.txt al abrirlo se observaran muchos caracteres pero al inicio dice ‰PNG por lo que cambiamos la extension a .png lo abrimos y obtenemos la bandera picoCTF{now_you_know_about_extensions}
```

## Bandera

picoCTF{now_you_know_about_extensions}

## Notas adicionales

## Referencias