# So Meta

## Descripcion

Find the flag in this [picture](https://jupiter.challenges.picoctf.org/static/916b07b4c87062c165ace1d3d31ef655/pico_img.png).

## Pistas

-   What does meta mean in the context of files?
-   Ever heard of metadata?

## Solucion

```
Descargamos la imagen del link al abrirla no notaremos nada raro pero lo siguiente que haremos es buscar un exiftools online en este caso el de la siguiente liga https://exif.tools/upload.php cargaremos la imagen y veremos que nos da varios metadatos al ver al artista se encontrara la bandera picoCTF{s0_m3ta_d8944929}
```

## Bandera

picoCTF{s0_m3ta_d8944929}

## Notas adicionales

## Referencias

-   [exiftool](https://exif.tools/upload.php)