# The numbers

## Descripcion

The [numbers](https://jupiter.challenges.picoctf.org/static/f209a32253affb6f547a585649ba4fda/the_numbers.png)... what do they mean?

## Pistas

-   The flag is in the format PICOCTF{}

## Solucion

```
Abrimos la imagen y vemos lo siguiente : 
16 9 3 15 3 20 6 { 20 8 5 14 21 13 2 5 18 19 13 1 19 15 14 } 
tomando en cuenta que la bandera tiene el formato de PICOCTF se puede deducir que el 3 es igual a la C y coincide por lo que el numero representa una letra acomodando obtenemos la bandera que es:
PICOCTF{THENUMBERSMASON}
```

## Bandera

PICOCTF{THENUMBERSMASON}

## Notas adicionales

## Referencias