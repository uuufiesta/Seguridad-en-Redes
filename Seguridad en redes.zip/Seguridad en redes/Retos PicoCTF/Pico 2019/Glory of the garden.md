# Glory of the Garden

## Descripcion

This [garden](https://jupiter.challenges.picoctf.org/static/4153422e18d40363e7ffc7e15a108683/garden.jpg) contains more than it seems.

## Pistas

-   What is a hex editor?

## Solucion

```
Descargamos la imagen del link al abrirla no notaremos nada raro pero lo siguiente que haremos es buscar un editor hexadecimal tal como lo sugiere la pista en este caso usaremos la siguiente pagina https://hexed.it/ al ver lo que nos regresa veremos muchos caracteres vamos al final y encontraremos la flag Here is a flag "picoCTF{more_than_m33ts_the_3y33dd2eEF5}"
```

## Bandera

picoCTF{more_than_m33ts_the_3y33dd2eEF5}

## Notas adicionales

## Referencias

-   [hexedit](https://hexed.it/)