## Descripcion

The factory is hiding things from all of its users. Can you login as Joe and find what they've been looking at? `https://jupiter.challenges.picoctf.org/problem/44573/` ([link](https://jupiter.challenges.picoctf.org/problem/44573/)) or [http://jupiter.challenges.picoctf.org:44573](http://jupiter.challenges.picoctf.org:44573/)

## Pistas

-   Hmm it doesn't seem to check anyone's password, except for Joe's?

## Solucion

```
Ingresamos a la pagina con cualquier usuario y cualquier contraseña ya que solo verifica la de joe ya dentro agregamos a google la extension de cookie editor editamos la variable admin a True guardamos y refrescamos la pagina obteniendo la bandera
**Flag**: `picoCTF{th3_c0nsp1r4cy_l1v3s_0c98aacc}`
```

## Bandera

picoCTF{th3_c0nsp1r4cy_l1v3s_0c98aacc}

## Notas adicionales

## Referencias