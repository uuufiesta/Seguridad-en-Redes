# Caesar

## Descripcion

Decrypt this [message](https://jupiter.challenges.picoctf.org/static/7d707a443e95054dc4cf30b1d9522ef0/ciphertext).

## Pistas

-   caesar cipher [tutorial](https://learncryptography.com/classical-encryption/caesar-cipher)

## Solucion

```
Abrimos el archivo en el editor de textos obteniendo lo siguiente: picoCTF{gvswwmrkxlivyfmgsrhnrisegl} como la pista nos indica se uso un cifrado caesar por lo que usaremos una herramienta especial para desencyptar la bandera obteniendo al cuarto intento de a->e : crossingtherubicondjneoach

```

## Bandera

picoCTF{crossingtherubicondjneoach}

## Notas adicionales

## Referencias

-   [CipherCaesar](https://cryptii.com/pipes/caesar-cipher)