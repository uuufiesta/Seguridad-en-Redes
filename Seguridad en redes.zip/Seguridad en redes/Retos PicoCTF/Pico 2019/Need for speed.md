# Need For Speed

## Descripcion

The name of the game is [speed](https://www.youtube.com/watch?v=8piqd2BWeGI). Are you quick enough to solve this problem and keep it above 50 mph? [need-for-speed](https://jupiter.challenges.picoctf.org/static/f9abc386dfb1309e687344783f208b20/need-for-speed).

## Pistas

-   What is the final key?

## Solucion
``

```
 Creamos un parche obteniendo la bandera:
 Keep this thing over 50 mph!
============================

Creating key...
Finished
Printing flag:
PICOCTF{Good job keeping bus #190ca38b speeding along!}

```

## Bandera

PICOCTF{Good job keeping bus #190ca38b speeding along!}

## Notas adicionales

## Referencias