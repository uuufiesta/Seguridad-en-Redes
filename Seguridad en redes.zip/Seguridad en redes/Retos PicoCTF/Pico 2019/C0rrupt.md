# c0rrupt

## Descripcion

We found this [file](https://jupiter.challenges.picoctf.org/static/ab30fcb7d47364b4190a7d3d40edb551/mystery). Recover the flag.

## Pistas

-   Try fixing the file header

## Solucion

```
Descargamos el archivo de la pagina mystery y en este caso lo convertiremos a png por lo que usamos hexedit para modificar los bits corruptos que se encuentran en el inicio del archivo obteniendo la flag picoCTF{c0rrupt10n_1847995}
```

## Bandera

picoCTF{c0rrupt10n_1847995}

## Notas adicionales

## Referencias

-   [hexedit](https://hexed.it/)