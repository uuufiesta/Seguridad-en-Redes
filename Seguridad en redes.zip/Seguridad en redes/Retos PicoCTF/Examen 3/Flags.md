# Flags

## Descripcion

What do the [flags](https://jupiter.challenges.picoctf.org/static/fbeb5f9040d62b18878d199cdda2d253/flag.png) mean?

## Pistas

-   The flag is in the format PICOCTF{}

## Solucion

```
Descargamos y abrimos la imagen dandonos cuenta que son banderas maritimas por lo que buscamos una pagina de las banderas maritimas y asi obtenemos la bandera:
PICOCTF{F1AG5AND5TUFF}
```

## Bandera

PICOCTF{F1AG5AND5TUFF}

## Notas adicionales

## Referencias

-   [banderas maritimas](https://marinos.es/banderas-barcos/)