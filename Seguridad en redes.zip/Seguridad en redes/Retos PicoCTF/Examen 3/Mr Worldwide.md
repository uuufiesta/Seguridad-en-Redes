# Mr-Worldwide

## Descripcion

A musician left us a [message](https://jupiter.challenges.picoctf.org/static/d5570d48262dbba2a31f2a940409ad9d/message.txt). What's it mean?

## Pistas

## Solucion

```
Descargamos y abrimos el archivo txt dandonos cuenta que son coordenadas por lo que buscamos una pagina la cual nos mapie dichas cordenadas y despues de mapeadas tomamos la primer letra de la ciudad de la coordenada obteniendo la bandera:
picoCTF{KODIAK_ALASKA}
```

## Bandera

picoCTF{KODIAK_ALASKA}

## Notas adicionales

## Referencias

-   [Google Maps](https://www.google.com.mx/maps)